import {
  IMiddleware,
  Middleware,
  Next,
  ProviderScope,
  Scope,
  UseAfter,
} from "@tsed/common";
import { useDecorators } from "@tsed/core";
import { Transactional } from "../../annotations/transactional-service.annotation";
import { DatabaseClient } from "../../clients/database.client";

@Transactional(Middleware)
export class CommitAfterTransactionMiddleware implements IMiddleware {

  constructor(
    private transaction: DatabaseClient
  ) {
  }

  public async use(
    @Next() next: CallableFunction,
  ) {
    await this.transaction.saveAndClose()

    return next();
  }
}

export const CommitTransactionAfter = () => {
  return useDecorators(
    UseAfter(CommitAfterTransactionMiddleware),
    Scope(ProviderScope.REQUEST)
  );
}
