import { ResponseFilter, Context, ResponseFilterMethods } from "@tsed/common";
import { extractId } from "../../utils/entity-utils";

@ResponseFilter("*/*")
export class WrapperResponseFilter implements ResponseFilterMethods {
  transform(data: any, ctx: Context) {
    if (typeof data !== "object") return data;

    const result = JSON.parse(JSON.stringify(data));

    if ("_refId" in result) {
      result.id = extractId(result);
    }

    return result;
  }
}
