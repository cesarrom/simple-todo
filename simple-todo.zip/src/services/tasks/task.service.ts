import { TASK_STATUSES } from "../../constants";
import { Transactional } from "../../annotations/transactional-service.annotation";
import { Task, TaskConstructor } from "../../models";
import { TaskRepository } from "../../repositories/task.repository";
import { extractId } from "../../utils/entity-utils";
import { CreateTaskRequest } from "../../controllers/requests/create-task.request";
import { UpdateTaskRequest } from "../../controllers/requests/update-task.request";

@Transactional()
export class TaskService {
  constructor(private taskRepository: TaskRepository) {}

  async findTask(userId: string, taskId: string) {
    const [task] = await this.taskRepository.getAll({
      userIdIn: [userId],
      idIn: [taskId],
    });

    return task;
  }

  listTasks(userId: string) {
    return this.taskRepository.getAll({
      userIdIn: [userId],
    });
  }

  async updateTask(userId: string, taskId: string, body: UpdateTaskRequest) {
    const task = await this.findTask(userId, taskId);

    return this.taskRepository.updateById(
      extractId(task),
      new Task({ ...task, ...body })
    );
  }

  createTask(userId: string, body: CreateTaskRequest) {
    return this.taskRepository.create(
      new Task({
        ...body,
        state: TASK_STATUSES.TODO,
        users: [userId],
      })
    );
  }
}
